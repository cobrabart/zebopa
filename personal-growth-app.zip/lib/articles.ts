export interface ArticleSubmission {
  id: string
  title: string
  content: string
  excerpt: string
  author: {
    id: string
    name: string
    email: string
  }
  category: string
  tags: string[]
  status: "draft" | "submitted" | "under_review" | "approved" | "published" | "rejected"
  submittedAt: Date
  publishedAt?: Date
  reviewNotes?: string
  views: number
  likes: number
  readingTime: number
}

export interface ArticleCategory {
  id: string
  name: string
  description: string
  icon: string
}

export const articleCategories: ArticleCategory[] = [
  {
    id: "personal-growth",
    name: "Personal Growth",
    description: "Stories about self-improvement and development",
    icon: "🌱",
  },
  {
    id: "mindfulness",
    name: "Mindfulness",
    description: "Meditation, awareness, and present-moment practices",
    icon: "🧘",
  },
  {
    id: "relationships",
    name: "Relationships",
    description: "Building better connections with others",
    icon: "💝",
  },
  {
    id: "career",
    name: "Career & Purpose",
    description: "Professional development and finding your calling",
    icon: "🎯",
  },
  {
    id: "wellness",
    name: "Health & Wellness",
    description: "Physical and mental health insights",
    icon: "💪",
  },
  {
    id: "creativity",
    name: "Creativity",
    description: "Unlocking creative potential and expression",
    icon: "🎨",
  },
]

// Calculate reading time based on word count
export const calculateReadingTime = (content: string): number => {
  const wordsPerMinute = 200
  const wordCount = content.trim().split(/\s+/).length
  return Math.ceil(wordCount / wordsPerMinute)
}

// Generate excerpt from content
export const generateExcerpt = (content: string, maxLength = 150): string => {
  const plainText = content.replace(/<[^>]*>/g, "").trim()
  if (plainText.length <= maxLength) return plainText
  return plainText.substring(0, maxLength).trim() + "..."
}

// Mock data for user articles
export const getUserArticles = (userId: string): ArticleSubmission[] => {
  return [
    {
      id: "1",
      title: "My Journey to Morning Meditation",
      content: `# My Journey to Morning Meditation

Starting a meditation practice was one of the most challenging yet rewarding decisions I've made. Here's how I built a sustainable morning routine that changed my life.

## The Beginning

Like many people, I struggled with consistency. I would meditate for a few days, then skip a week. The key was starting small - just 5 minutes each morning.

## Building the Habit

The breakthrough came when I linked meditation to my existing morning routine. Right after brushing my teeth, I would sit for my practice. This simple connection made all the difference.

## The Benefits

After three months of consistent practice, I noticed:
- Better emotional regulation
- Improved focus throughout the day
- More patience with difficult situations
- A sense of inner calm that carries through challenges

## Tips for Beginners

1. Start with just 5 minutes
2. Use a meditation app for guidance
3. Be patient with yourself
4. Focus on consistency over perfection

The journey continues, and each day brings new insights and growth.`,
      excerpt:
        "Starting a meditation practice was one of the most challenging yet rewarding decisions I've made. Here's how I built a sustainable morning routine...",
      author: {
        id: userId,
        name: "John Doe",
        email: "john@example.com",
      },
      category: "mindfulness",
      tags: ["meditation", "morning-routine", "habits"],
      status: "published",
      submittedAt: new Date("2024-02-15"),
      publishedAt: new Date("2024-02-20"),
      views: 1247,
      likes: 89,
      readingTime: 4,
    },
    {
      id: "2",
      title: "Overcoming Imposter Syndrome in Tech",
      content: `# Overcoming Imposter Syndrome in Tech

Imposter syndrome affects many professionals, especially in fast-moving fields like technology. Here's my story of recognizing and overcoming these feelings.

## Recognizing the Signs

For months, I felt like I didn't belong in my role. Despite positive feedback, I constantly worried that people would discover I wasn't as capable as they thought.

## The Turning Point

A mentor helped me realize that feeling challenged and uncertain is normal - it means you're growing. The key is distinguishing between healthy self-reflection and destructive self-doubt.

## Strategies That Helped

- Keeping a "wins" journal
- Seeking feedback regularly
- Connecting with other professionals facing similar challenges
- Focusing on continuous learning rather than perfection

## Moving Forward

Imposter syndrome still visits occasionally, but now I have tools to manage it. Remember: you earned your place, and growth is a lifelong journey.`,
      excerpt:
        "Imposter syndrome affects many professionals, especially in fast-moving fields like technology. Here's my story of recognizing and overcoming these feelings.",
      author: {
        id: userId,
        name: "John Doe",
        email: "john@example.com",
      },
      category: "career",
      tags: ["imposter-syndrome", "career-growth", "confidence"],
      status: "under_review",
      submittedAt: new Date("2024-03-01"),
      views: 0,
      likes: 0,
      readingTime: 3,
    },
  ]
}

export const submitArticle = async (
  article: Omit<ArticleSubmission, "id" | "submittedAt" | "views" | "likes">,
): Promise<ArticleSubmission> => {
  // Mock API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const newArticle: ArticleSubmission = {
    ...article,
    id: Date.now().toString(),
    submittedAt: new Date(),
    views: 0,
    likes: 0,
  }

  return newArticle
}

export const updateArticle = async (
  articleId: string,
  updates: Partial<ArticleSubmission>,
): Promise<ArticleSubmission> => {
  // Mock API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Return updated article (mock)
  const existingArticle = getUserArticles("demo-user").find((a) => a.id === articleId)
  if (!existingArticle) throw new Error("Article not found")

  return { ...existingArticle, ...updates }
}

export const deleteArticle = async (articleId: string): Promise<void> => {
  // Mock API call
  await new Promise((resolve) => setTimeout(resolve, 500))
  console.log(`Deleted article ${articleId}`)
}
