export interface AdminStats {
  totalUsers: number
  activeUsers: number
  totalChallenges: number
  completedChallenges: number
  totalKnowledgeItems: number
  totalArticleSubmissions: number
  averageEngagement: number
}

export interface UserManagement {
  id: string
  name: string
  email: string
  level: number
  totalPoints: number
  streak: number
  joinedAt: Date
  lastActive: Date
  status: "active" | "inactive" | "suspended"
}

export interface ContentManagement {
  id: string
  title: string
  type: "challenge" | "knowledge" | "article"
  author: string
  status: "draft" | "published" | "archived"
  createdAt: Date
  views: number
  engagement: number
}

// Mock data for admin dashboard
export const getAdminStats = (): AdminStats => {
  return {
    totalUsers: 1247,
    activeUsers: 892,
    totalChallenges: 365,
    completedChallenges: 12847,
    totalKnowledgeItems: 156,
    totalArticleSubmissions: 89,
    averageEngagement: 78.5,
  }
}

export const getUsers = (): UserManagement[] => {
  return [
    {
      id: "1",
      name: "John Doe",
      email: "john@example.com",
      level: 5,
      totalPoints: 2450,
      streak: 12,
      joinedAt: new Date("2024-01-15"),
      lastActive: new Date("2024-03-10"),
      status: "active",
    },
    {
      id: "2",
      name: "Sarah Wilson",
      email: "sarah@example.com",
      level: 8,
      totalPoints: 3890,
      streak: 25,
      joinedAt: new Date("2023-11-20"),
      lastActive: new Date("2024-03-09"),
      status: "active",
    },
    {
      id: "3",
      name: "Mike Johnson",
      email: "mike@example.com",
      level: 3,
      totalPoints: 1250,
      streak: 0,
      joinedAt: new Date("2024-02-01"),
      lastActive: new Date("2024-02-28"),
      status: "inactive",
    },
  ]
}

export const getContentItems = (): ContentManagement[] => {
  return [
    {
      id: "1",
      title: "Morning Mindfulness Challenge",
      type: "challenge",
      author: "Admin",
      status: "published",
      createdAt: new Date("2024-03-01"),
      views: 1247,
      engagement: 85.2,
    },
    {
      id: "2",
      title: "Building Emotional Intelligence",
      type: "knowledge",
      author: "Dr. Smith",
      status: "published",
      createdAt: new Date("2024-02-28"),
      views: 892,
      engagement: 92.1,
    },
    {
      id: "3",
      title: "My Journey to Self-Discovery",
      type: "article",
      author: "User123",
      status: "draft",
      createdAt: new Date("2024-03-05"),
      views: 0,
      engagement: 0,
    },
  ]
}

export const updateUserStatus = async (userId: string, status: UserManagement["status"]): Promise<void> => {
  // Mock API call
  await new Promise((resolve) => setTimeout(resolve, 500))
  console.log(`Updated user ${userId} status to ${status}`)
}

export const updateContentStatus = async (contentId: string, status: ContentManagement["status"]): Promise<void> => {
  // Mock API call
  await new Promise((resolve) => setTimeout(resolve, 500))
  console.log(`Updated content ${contentId} status to ${status}`)
}
