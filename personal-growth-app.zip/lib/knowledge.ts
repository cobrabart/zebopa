export interface KnowledgeItem {
  id: string
  title: string
  description: string
  content: string
  type: "article" | "book" | "video" | "podcast" | "exercise" | "guide"
  category:
    | "personal-development"
    | "mindfulness"
    | "productivity"
    | "relationships"
    | "health"
    | "career"
    | "leadership"
  difficulty: "beginner" | "intermediate" | "advanced"
  readingTime: string
  tags: string[]
  author: string
  publishedAt: Date
  featured: boolean
  downloadUrl?: string
  externalUrl?: string
  imageUrl?: string
}

export interface KnowledgeCategory {
  id: string
  name: string
  description: string
  icon: string
  color: string
  itemCount: number
}

export interface UserProgress {
  userId: string
  itemId: string
  status: "not_started" | "in_progress" | "completed"
  progress: number // 0-100
  startedAt?: Date
  completedAt?: Date
  bookmarks: boolean
  rating?: number
  notes?: string
}

// Mock knowledge categories
export const knowledgeCategories: KnowledgeCategory[] = [
  {
    id: "personal-development",
    name: "Personal Development",
    description: "Build self-awareness, confidence, and personal growth skills",
    icon: "🌱",
    color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
    itemCount: 24,
  },
  {
    id: "mindfulness",
    name: "Mindfulness & Meditation",
    description: "Develop presence, awareness, and inner peace",
    icon: "🧘",
    color: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300",
    itemCount: 18,
  },
  {
    id: "productivity",
    name: "Productivity",
    description: "Optimize your time, energy, and focus for better results",
    icon: "⚡",
    color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
    itemCount: 21,
  },
  {
    id: "relationships",
    name: "Relationships",
    description: "Build stronger connections and communication skills",
    icon: "💝",
    color: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300",
    itemCount: 16,
  },
  {
    id: "health",
    name: "Health & Wellness",
    description: "Physical and mental health practices for well-being",
    icon: "💪",
    color: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
    itemCount: 19,
  },
  {
    id: "career",
    name: "Career Growth",
    description: "Professional development and leadership skills",
    icon: "🚀",
    color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
    itemCount: 22,
  },
]

// Mock knowledge items
export const mockKnowledgeItems: KnowledgeItem[] = [
  {
    id: "1",
    title: "The Power of Morning Routines",
    description: "Discover how a structured morning routine can transform your entire day and boost productivity.",
    content: `# The Power of Morning Routines

A well-designed morning routine is one of the most powerful tools for personal transformation. Research shows that how you start your day sets the tone for everything that follows.

## Why Morning Routines Matter

Your morning routine creates momentum that carries through your entire day. When you begin with intention and structure, you:

- Build discipline and willpower
- Reduce decision fatigue
- Create positive momentum
- Improve focus and clarity
- Enhance overall well-being

## Key Elements of an Effective Morning Routine

### 1. Wake Up Early
Give yourself time to ease into the day without rushing. Even 30 minutes earlier can make a significant difference.

### 2. Hydrate Immediately
Your body has been without water for 6-8 hours. Start with a large glass of water to kickstart your metabolism.

### 3. Move Your Body
Whether it's stretching, yoga, or a full workout, physical movement energizes your body and mind.

### 4. Practice Mindfulness
Spend 5-10 minutes in meditation, journaling, or simply sitting quietly to center yourself.

### 5. Set Daily Intentions
Review your goals and priorities for the day. This creates focus and purpose.

## Building Your Routine

Start small and build gradually. Choose 2-3 elements that resonate with you and practice them consistently for 21 days before adding more.

Remember: The best morning routine is the one you'll actually stick to. Customize it to fit your lifestyle and preferences.`,
    type: "article",
    category: "productivity",
    difficulty: "beginner",
    readingTime: "5 min read",
    tags: ["morning-routine", "productivity", "habits", "wellness"],
    author: "Dr. Sarah Johnson",
    publishedAt: new Date("2024-01-15"),
    featured: true,
    imageUrl: "/peaceful-morning-sunrise-routine.jpg",
  },
  {
    id: "2",
    title: "Emotional Intelligence Mastery",
    description: "Learn to understand, manage, and leverage emotions for better relationships and success.",
    content: `# Emotional Intelligence Mastery

Emotional Intelligence (EI) is the ability to recognize, understand, and manage our own emotions while effectively recognizing and responding to others' emotions.

## The Four Domains of Emotional Intelligence

### 1. Self-Awareness
- Recognizing your emotions as they occur
- Understanding your emotional triggers
- Knowing your strengths and limitations

### 2. Self-Management
- Controlling impulsive feelings and behaviors
- Managing emotions in healthy ways
- Taking initiative and following through on commitments

### 3. Social Awareness
- Understanding others' emotions and concerns
- Reading social and organizational dynamics
- Showing empathy and compassion

### 4. Relationship Management
- Communicating clearly and effectively
- Managing conflict constructively
- Building and maintaining healthy relationships

## Developing Your Emotional Intelligence

### Practice Daily Self-Check-ins
Ask yourself: "What am I feeling right now? Why am I feeling this way?"

### Learn to Pause
Before reacting emotionally, take a moment to breathe and consider your response.

### Develop Empathy
Try to see situations from others' perspectives before judging or responding.

### Improve Your Communication
Express your feelings clearly and listen actively to others.

## The Benefits

Higher emotional intelligence leads to:
- Better relationships
- Improved leadership skills
- Greater resilience
- Enhanced decision-making
- Increased life satisfaction`,
    type: "guide",
    category: "personal-development",
    difficulty: "intermediate",
    readingTime: "8 min read",
    tags: ["emotional-intelligence", "self-awareness", "relationships", "communication"],
    author: "Dr. Michael Chen",
    publishedAt: new Date("2024-01-10"),
    featured: true,
    imageUrl: "/emotional-intelligence-brain-connections.jpg",
  },
  {
    id: "3",
    title: "Mindful Breathing Techniques",
    description: "Simple yet powerful breathing exercises to reduce stress and increase focus.",
    content: `# Mindful Breathing Techniques

Breathing is the bridge between the conscious and unconscious mind. These techniques can help you manage stress, improve focus, and enhance overall well-being.

## Basic Mindful Breathing

1. Find a comfortable position
2. Close your eyes or soften your gaze
3. Focus on your natural breath
4. When your mind wanders, gently return to the breath
5. Start with 5 minutes, gradually increase

## Advanced Techniques

### 4-7-8 Breathing
- Inhale for 4 counts
- Hold for 7 counts
- Exhale for 8 counts
- Repeat 4 times

### Box Breathing
- Inhale for 4 counts
- Hold for 4 counts
- Exhale for 4 counts
- Hold empty for 4 counts

### Alternate Nostril Breathing
- Use thumb to close right nostril, inhale through left
- Close left nostril with ring finger, release thumb, exhale right
- Inhale right, close right, release left, exhale left
- Continue for 5-10 rounds

## When to Practice

- Morning: To start the day centered
- Before meals: To aid digestion
- During stress: To calm the nervous system
- Before sleep: To prepare for rest

## Benefits

Regular practice leads to:
- Reduced anxiety and stress
- Improved focus and concentration
- Better sleep quality
- Enhanced emotional regulation
- Increased energy levels`,
    type: "exercise",
    category: "mindfulness",
    difficulty: "beginner",
    readingTime: "6 min read",
    tags: ["breathing", "meditation", "stress-relief", "mindfulness"],
    author: "Zen Master Liu",
    publishedAt: new Date("2024-01-08"),
    featured: false,
    imageUrl: "/peaceful-meditation-breathing-exercise.jpg",
  },
  {
    id: "4",
    title: "Building Resilience in Challenging Times",
    description: "Develop the mental strength to bounce back from setbacks and thrive under pressure.",
    content: `# Building Resilience in Challenging Times

Resilience is not about avoiding difficulties—it's about developing the capacity to navigate through them and emerge stronger.

## Understanding Resilience

Resilience is the ability to:
- Adapt to adversity
- Recover from setbacks
- Learn from challenges
- Maintain hope during difficult times
- Continue moving forward despite obstacles

## The Pillars of Resilience

### 1. Mental Flexibility
- Challenge negative thought patterns
- Reframe situations positively
- Focus on what you can control
- Practice acceptance of what you cannot change

### 2. Emotional Regulation
- Acknowledge your feelings without judgment
- Use healthy coping strategies
- Seek support when needed
- Practice self-compassion

### 3. Social Connection
- Build and maintain supportive relationships
- Communicate openly about challenges
- Offer help to others
- Join communities with shared values

### 4. Purpose and Meaning
- Connect with your core values
- Find meaning in difficult experiences
- Set meaningful goals
- Contribute to something larger than yourself

## Practical Strategies

### Daily Practices
- Gratitude journaling
- Regular exercise
- Mindfulness meditation
- Adequate sleep and nutrition

### During Crisis
- Break problems into manageable steps
- Focus on immediate next actions
- Seek multiple perspectives
- Remember past successes

### Long-term Building
- Develop diverse coping skills
- Build a strong support network
- Continuously learn and grow
- Practice stress management techniques

## The Growth Mindset

View challenges as opportunities to:
- Develop new skills
- Discover inner strength
- Deepen relationships
- Clarify priorities
- Build character

Remember: Resilience is not a trait you're born with—it's a skill you can develop through practice and intention.`,
    type: "article",
    category: "personal-development",
    difficulty: "intermediate",
    readingTime: "10 min read",
    tags: ["resilience", "mental-health", "stress-management", "growth-mindset"],
    author: "Dr. Amanda Rodriguez",
    publishedAt: new Date("2024-01-05"),
    featured: true,
    imageUrl: "/resilience-mountain-climbing-strength.jpg",
  },
  {
    id: "5",
    title: "The Art of Active Listening",
    description: "Master the skill that transforms relationships and builds deeper connections.",
    content: `# The Art of Active Listening

Active listening is more than just hearing words—it's about fully engaging with the speaker and creating a space for genuine understanding.

## What is Active Listening?

Active listening involves:
- Giving full attention to the speaker
- Understanding both words and emotions
- Responding thoughtfully
- Avoiding judgment
- Creating a safe space for communication

## The Components of Active Listening

### 1. Physical Presence
- Face the speaker
- Maintain appropriate eye contact
- Use open body language
- Minimize distractions
- Show you're engaged through posture

### 2. Mental Presence
- Focus completely on the speaker
- Avoid planning your response
- Set aside your own agenda
- Be curious about their perspective
- Stay present in the moment

### 3. Emotional Presence
- Tune into the speaker's emotions
- Show empathy and understanding
- Validate their feelings
- Avoid rushing to fix or solve
- Create emotional safety

## Active Listening Techniques

### Paraphrasing
"What I hear you saying is..."
"It sounds like you feel..."
"Let me make sure I understand..."

### Asking Open Questions
"Can you tell me more about that?"
"How did that make you feel?"
"What was that experience like for you?"

### Reflecting Emotions
"You seem frustrated about..."
"I can hear the excitement in your voice..."
"That must have been difficult..."

### Summarizing
"So the main points are..."
"If I understand correctly..."
"The key issues seem to be..."

## Common Barriers to Active Listening

### Internal Barriers
- Preoccupation with your own thoughts
- Judging the speaker
- Planning your response
- Emotional reactions
- Assumptions and biases

### External Barriers
- Environmental distractions
- Time pressure
- Technology interruptions
- Uncomfortable setting
- Multiple conversations

## Benefits of Active Listening

### For Relationships
- Builds trust and rapport
- Reduces conflicts
- Increases intimacy
- Shows respect and care
- Improves communication

### For Personal Growth
- Develops empathy
- Increases emotional intelligence
- Expands perspectives
- Builds patience
- Enhances learning

## Practice Exercises

### Daily Practice
- Choose one conversation per day to practice active listening
- Put away devices during conversations
- Practice the 80/20 rule: listen 80%, talk 20%
- Ask follow-up questions instead of sharing your own stories

### Advanced Practice
- Listen to understand, not to respond
- Practice listening to difficult or opposing viewpoints
- Focus on emotions behind the words
- Use silence as a tool to encourage deeper sharing

Remember: Active listening is a gift you give to others and yourself. It transforms ordinary conversations into meaningful connections.`,
    type: "guide",
    category: "relationships",
    difficulty: "intermediate",
    readingTime: "12 min read",
    tags: ["communication", "listening", "relationships", "empathy"],
    author: "Dr. Jennifer Walsh",
    publishedAt: new Date("2024-01-03"),
    featured: false,
    imageUrl: "/active-listening-conversation-connection.jpg",
  },
  {
    id: "6",
    title: "Time Management Mastery",
    description: "Proven strategies to take control of your time and maximize productivity.",
    content: `# Time Management Mastery

Effective time management isn't about doing more things—it's about doing the right things efficiently and creating space for what matters most.

## The Foundation: Understanding Your Relationship with Time

### Time Audit
Track how you spend your time for one week:
- Work tasks and meetings
- Personal activities
- Social media and entertainment
- Commuting and transitions
- Rest and self-care

### Identify Your Peak Hours
- When do you have the most energy?
- When are you most creative?
- When do you focus best?
- When do you feel most motivated?

## Core Time Management Principles

### 1. Priority Matrix (Eisenhower Method)
Categorize tasks by urgency and importance:
- **Quadrant 1**: Urgent + Important (Do first)
- **Quadrant 2**: Not Urgent + Important (Schedule)
- **Quadrant 3**: Urgent + Not Important (Delegate)
- **Quadrant 4**: Not Urgent + Not Important (Eliminate)

### 2. Time Blocking
- Assign specific time slots to different activities
- Include buffer time between tasks
- Block time for deep work
- Schedule breaks and personal time

### 3. The 80/20 Rule (Pareto Principle)
- 80% of results come from 20% of efforts
- Identify your high-impact activities
- Focus more time on what produces the best results
- Minimize or eliminate low-value tasks

## Practical Strategies

### Daily Planning
- Plan your day the night before
- Start with your most important task
- Limit your daily priorities to 3-5 items
- Build in flexibility for unexpected events

### Weekly Planning
- Review and plan every Sunday
- Set weekly goals and priorities
- Schedule important but not urgent tasks
- Plan for personal time and self-care

### Monthly Planning
- Set monthly objectives
- Review progress on long-term goals
- Adjust systems and processes
- Plan for upcoming challenges and opportunities

## Common Time Wasters and Solutions

### Procrastination
- Break large tasks into smaller steps
- Use the 2-minute rule: if it takes less than 2 minutes, do it now
- Create accountability systems
- Address underlying fears or perfectionism

### Interruptions
- Set boundaries with colleagues and family
- Use "do not disturb" signals
- Batch similar tasks together
- Create interruption-free time blocks

### Perfectionism
- Set "good enough" standards for routine tasks
- Use time limits for decision-making
- Focus on progress over perfection
- Remember that done is better than perfect

## Technology Tools

### Digital Calendars
- Google Calendar, Outlook, or Apple Calendar
- Color-code different types of activities
- Set reminders and notifications
- Share calendars with family or team

### Task Management Apps
- Todoist, Things, or Asana
- Capture all tasks in one system
- Set due dates and priorities
- Review and update regularly

### Time Tracking Apps
- RescueTime, Toggl, or Clockify
- Monitor how you actually spend time
- Identify patterns and time drains
- Make data-driven improvements

## Advanced Techniques

### Pomodoro Technique
- Work for 25 minutes, then take a 5-minute break
- After 4 pomodoros, take a longer 15-30 minute break
- Helps maintain focus and prevent burnout
- Great for tasks requiring sustained attention

### Energy Management
- Match tasks to your energy levels
- Do creative work during peak hours
- Handle routine tasks during low-energy times
- Take breaks before you feel tired

### Batch Processing
- Group similar tasks together
- Handle all emails at designated times
- Make all phone calls in one session
- Prepare meals for the week at once

## Creating Boundaries

### Learn to Say No
- Evaluate requests against your priorities
- Offer alternatives when possible
- Be polite but firm
- Remember that saying no to one thing means saying yes to something else

### Protect Your Time
- Schedule personal time like important meetings
- Turn off notifications during focused work
- Create physical and mental boundaries
- Communicate your availability clearly

## Measuring Success

### Key Metrics
- Completion rate of important tasks
- Time spent on high-priority activities
- Stress levels and work-life balance
- Progress toward long-term goals

### Regular Reviews
- Daily: What went well? What could improve?
- Weekly: Are you on track with your goals?
- Monthly: What systems need adjustment?
- Quarterly: Are your priorities still aligned with your values?

Remember: Time management is really life management. The goal isn't to fill every moment with productivity, but to create space for what truly matters to you.`,
    type: "guide",
    category: "productivity",
    difficulty: "intermediate",
    readingTime: "15 min read",
    tags: ["time-management", "productivity", "planning", "efficiency"],
    author: "David Kim",
    publishedAt: new Date("2024-01-01"),
    featured: true,
    imageUrl: "/time-management-clock-productivity-planning.jpg",
  },
]

// Mock user progress data
export const mockUserProgress: UserProgress[] = [
  {
    userId: "1",
    itemId: "1",
    status: "completed",
    progress: 100,
    startedAt: new Date("2024-01-15T09:00:00"),
    completedAt: new Date("2024-01-15T09:15:00"),
    bookmarks: true,
    rating: 5,
    notes: "Great insights on building morning routines. Started implementing immediately.",
  },
  {
    userId: "1",
    itemId: "2",
    status: "in_progress",
    progress: 60,
    startedAt: new Date("2024-01-16T10:00:00"),
    bookmarks: true,
  },
]

export const getKnowledgeItems = (
  category?: string,
  difficulty?: string,
  type?: string,
  featured?: boolean,
): KnowledgeItem[] => {
  let items = [...mockKnowledgeItems]

  if (category) {
    items = items.filter((item) => item.category === category)
  }

  if (difficulty) {
    items = items.filter((item) => item.difficulty === difficulty)
  }

  if (type) {
    items = items.filter((item) => item.type === type)
  }

  if (featured !== undefined) {
    items = items.filter((item) => item.featured === featured)
  }

  return items.sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime())
}

export const getKnowledgeItem = (id: string): KnowledgeItem | null => {
  return mockKnowledgeItems.find((item) => item.id === id) || null
}

export const getUserProgress = (userId: string, itemId: string): UserProgress | null => {
  return mockUserProgress.find((progress) => progress.userId === userId && progress.itemId === itemId) || null
}

export const updateUserProgress = async (
  userId: string,
  itemId: string,
  updates: Partial<UserProgress>,
): Promise<UserProgress> => {
  const existingIndex = mockUserProgress.findIndex((p) => p.userId === userId && p.itemId === itemId)

  if (existingIndex >= 0) {
    mockUserProgress[existingIndex] = { ...mockUserProgress[existingIndex], ...updates }
    return mockUserProgress[existingIndex]
  } else {
    const newProgress: UserProgress = {
      userId,
      itemId,
      status: "not_started",
      progress: 0,
      bookmarks: false,
      ...updates,
    }
    mockUserProgress.push(newProgress)
    return newProgress
  }
}

export const searchKnowledgeItems = (query: string): KnowledgeItem[] => {
  const lowercaseQuery = query.toLowerCase()
  return mockKnowledgeItems.filter(
    (item) =>
      item.title.toLowerCase().includes(lowercaseQuery) ||
      item.description.toLowerCase().includes(lowercaseQuery) ||
      item.tags.some((tag) => tag.toLowerCase().includes(lowercaseQuery)) ||
      item.author.toLowerCase().includes(lowercaseQuery),
  )
}
