export interface Challenge {
  id: string
  title: string
  description: string
  type: "reflection" | "action" | "mindfulness" | "learning" | "physical"
  difficulty: "easy" | "medium" | "hard"
  points: number
  estimatedTime: string
  instructions: string[]
  mediaUrl?: string
  mediaType?: "image" | "video" | "audio"
  category: string
  tags: string[]
  createdAt: Date
}

export interface ChallengeSubmission {
  id: string
  challengeId: string
  userId: string
  content: string
  mediaUrl?: string
  mediaType?: "image" | "video" | "audio"
  completedAt: Date
  points: number
  reflection?: string
}

export interface UserProgress {
  userId: string
  challengeId: string
  status: "not_started" | "in_progress" | "completed"
  startedAt?: Date
  completedAt?: Date
  submission?: ChallengeSubmission
}

// Mock daily challenges data
export const mockChallenges: Challenge[] = [
  {
    id: "1",
    title: "Morning Gratitude Practice",
    description: "Start your day by writing down three things you're grateful for",
    type: "reflection",
    difficulty: "easy",
    points: 50,
    estimatedTime: "5 minutes",
    instructions: [
      "Find a quiet space to sit comfortably",
      "Think about your life and experiences",
      "Write down three specific things you're grateful for today",
      "For each item, write a brief explanation of why you're grateful",
      "Take a moment to feel the positive emotions",
    ],
    category: "Mindfulness",
    tags: ["gratitude", "morning", "reflection"],
    createdAt: new Date("2024-01-01"),
  },
  {
    id: "2",
    title: "Random Act of Kindness",
    description: "Perform one unexpected act of kindness for someone today",
    type: "action",
    difficulty: "medium",
    points: 100,
    estimatedTime: "15-30 minutes",
    instructions: [
      "Think of someone who could use a kind gesture",
      "Choose an action that would genuinely help or brighten their day",
      "Perform the act without expecting anything in return",
      "Document your experience and how it made you feel",
      "Reflect on the impact of kindness",
    ],
    category: "Social Connection",
    tags: ["kindness", "action", "community"],
    createdAt: new Date("2024-01-02"),
  },
  {
    id: "3",
    title: "5-Minute Breathing Meditation",
    description: "Practice focused breathing to center yourself and reduce stress",
    type: "mindfulness",
    difficulty: "easy",
    points: 75,
    estimatedTime: "5 minutes",
    instructions: [
      "Find a comfortable seated position",
      "Close your eyes or soften your gaze",
      "Focus on your natural breath",
      "Count each exhale from 1 to 10, then start over",
      "When your mind wanders, gently return to counting",
    ],
    category: "Mindfulness",
    tags: ["meditation", "breathing", "stress-relief"],
    createdAt: new Date("2024-01-03"),
  },
  {
    id: "4",
    title: "Learn Something New",
    description: "Spend 20 minutes learning about a topic that interests you",
    type: "learning",
    difficulty: "medium",
    points: 125,
    estimatedTime: "20 minutes",
    instructions: [
      "Choose a topic you've always been curious about",
      "Find a reliable source (article, video, podcast)",
      "Take notes on key insights",
      "Write a brief summary of what you learned",
      "Consider how this knowledge might be useful",
    ],
    category: "Personal Development",
    tags: ["learning", "curiosity", "growth"],
    createdAt: new Date("2024-01-04"),
  },
  {
    id: "5",
    title: "Digital Detox Hour",
    description: "Spend one hour completely disconnected from digital devices",
    type: "action",
    difficulty: "hard",
    points: 150,
    estimatedTime: "60 minutes",
    instructions: [
      "Turn off all digital devices (phone, computer, TV)",
      "Choose an analog activity (reading, drawing, walking)",
      "Notice any urges to check devices",
      "Focus on being present in the moment",
      "Reflect on how the experience felt",
    ],
    category: "Digital Wellness",
    tags: ["detox", "mindfulness", "presence"],
    createdAt: new Date("2024-01-05"),
  },
]

// Mock user progress data
export const mockUserProgress: UserProgress[] = [
  {
    userId: "1",
    challengeId: "1",
    status: "completed",
    startedAt: new Date("2024-01-01T08:00:00"),
    completedAt: new Date("2024-01-01T08:15:00"),
    submission: {
      id: "sub1",
      challengeId: "1",
      userId: "1",
      content: "1. My family's health and happiness\n2. Having a job I enjoy\n3. The beautiful sunrise this morning",
      completedAt: new Date("2024-01-01T08:15:00"),
      points: 50,
      reflection: "This practice helped me start the day with a positive mindset.",
    },
  },
  {
    userId: "1",
    challengeId: "2",
    status: "in_progress",
    startedAt: new Date("2024-01-02T10:00:00"),
  },
]

export const getTodaysChallenge = (): Challenge => {
  const today = new Date()
  const dayIndex = today.getDate() % mockChallenges.length
  return mockChallenges[dayIndex]
}

export const getUserProgress = (userId: string, challengeId: string): UserProgress | null => {
  return mockUserProgress.find((p) => p.userId === userId && p.challengeId === challengeId) || null
}

export const startChallenge = async (userId: string, challengeId: string): Promise<UserProgress> => {
  const progress: UserProgress = {
    userId,
    challengeId,
    status: "in_progress",
    startedAt: new Date(),
  }

  // In a real app, this would save to database
  mockUserProgress.push(progress)
  return progress
}

export const submitChallenge = async (
  userId: string,
  challengeId: string,
  content: string,
  mediaUrl?: string,
  mediaType?: "image" | "video" | "audio",
  reflection?: string,
): Promise<ChallengeSubmission> => {
  const challenge = mockChallenges.find((c) => c.id === challengeId)
  if (!challenge) throw new Error("Challenge not found")

  const submission: ChallengeSubmission = {
    id: Date.now().toString(),
    challengeId,
    userId,
    content,
    mediaUrl,
    mediaType,
    completedAt: new Date(),
    points: challenge.points,
    reflection,
  }

  // Update progress
  const progressIndex = mockUserProgress.findIndex((p) => p.userId === userId && p.challengeId === challengeId)
  if (progressIndex >= 0) {
    mockUserProgress[progressIndex].status = "completed"
    mockUserProgress[progressIndex].completedAt = new Date()
    mockUserProgress[progressIndex].submission = submission
  }

  return submission
}
