export interface User {
  id: string
  email: string
  name: string
  avatar?: string
  createdAt: Date
  streak: number
  totalPoints: number
  level: number
  badges: string[]
}

export interface AuthState {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
}

// Mock authentication - in production, replace with real auth service
export const mockUsers: User[] = [
  {
    id: "1",
    email: "demo@example.com",
    name: "Demo User",
    avatar: "/diverse-user-avatars.png",
    createdAt: new Date("2024-01-01"),
    streak: 7,
    totalPoints: 1250,
    level: 3,
    badges: ["early-bird", "consistent", "challenger"],
  },
]

export const signIn = async (email: string, password: string): Promise<User | null> => {
  // Mock authentication logic
  await new Promise((resolve) => setTimeout(resolve, 1000))

  if (email === "demo@example.com" && password === "demo123") {
    return mockUsers[0]
  }

  return null
}

export const signUp = async (email: string, password: string, name: string): Promise<User | null> => {
  // Mock registration logic
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const newUser: User = {
    id: Date.now().toString(),
    email,
    name,
    avatar: "/diverse-user-avatars.png",
    createdAt: new Date(),
    streak: 0,
    totalPoints: 0,
    level: 1,
    badges: [],
  }

  mockUsers.push(newUser)
  return newUser
}

export const signOut = async (): Promise<void> => {
  // Mock sign out logic
  await new Promise((resolve) => setTimeout(resolve, 500))
}
