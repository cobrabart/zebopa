"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { QuestionCard } from "./question-card"
import { ResultsDisplay } from "./results-display"
import {
  personalGrowthTest,
  calculateDiagnosticResult,
  saveDiagnosticResult,
  type DiagnosticAnswer,
  type DiagnosticResult,
} from "@/lib/diagnostic"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, ArrowRight, Clock, Target, Loader2 } from "lucide-react"

type TestState = "intro" | "taking" | "processing" | "results"

export function DiagnosticTest() {
  const [state, setState] = useState<TestState>("intro")
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState<DiagnosticAnswer[]>([])
  const [result, setResult] = useState<DiagnosticResult | null>(null)
  const { user } = useAuth()
  const { toast } = useToast()

  const currentQuestion = personalGrowthTest.questions[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / personalGrowthTest.questions.length) * 100
  const isLastQuestion = currentQuestionIndex === personalGrowthTest.questions.length - 1

  const getCurrentAnswer = () => {
    return answers.find((a) => a.questionId === currentQuestion?.id)?.value
  }

  const handleAnswer = (value: string | number | boolean) => {
    const newAnswer: DiagnosticAnswer = {
      questionId: currentQuestion.id,
      value,
      timestamp: new Date(),
    }

    setAnswers((prev) => {
      const filtered = prev.filter((a) => a.questionId !== currentQuestion.id)
      return [...filtered, newAnswer]
    })
  }

  const handleNext = () => {
    if (isLastQuestion) {
      handleSubmitTest()
    } else {
      setCurrentQuestionIndex((prev) => prev + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1)
    }
  }

  const handleSubmitTest = async () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to save your results",
        variant: "destructive",
      })
      return
    }

    setState("processing")

    try {
      const testResult = await calculateDiagnosticResult(user.id, personalGrowthTest.id, answers)

      await saveDiagnosticResult(testResult)
      setResult(testResult)
      setState("results")

      toast({
        title: "Assessment Complete!",
        description: "Your personalized recommendations are ready",
      })
    } catch (error) {
      toast({
        title: "Processing Failed",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      })
      setState("taking")
    }
  }

  const handleRetakeTest = () => {
    setCurrentQuestionIndex(0)
    setAnswers([])
    setResult(null)
    setState("intro")
  }

  const handleStartTest = () => {
    setState("taking")
  }

  if (state === "intro") {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">{personalGrowthTest.title}</CardTitle>
            <CardDescription className="text-base">{personalGrowthTest.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3 p-4 bg-muted rounded-lg">
                <Clock className="h-5 w-5 text-primary" />
                <div>
                  <div className="font-medium">Duration</div>
                  <div className="text-sm text-muted-foreground">{personalGrowthTest.estimatedTime}</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-4 bg-muted rounded-lg">
                <Target className="h-5 w-5 text-primary" />
                <div>
                  <div className="font-medium">Questions</div>
                  <div className="text-sm text-muted-foreground">{personalGrowthTest.questions.length} questions</div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium">What you'll discover:</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start space-x-2">
                  <span className="text-primary">•</span>
                  <span>Your current strengths across key life areas</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-primary">•</span>
                  <span>Areas with the most potential for growth</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-primary">•</span>
                  <span>Personalized AI-generated action plans</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-primary">•</span>
                  <span>Curated resources for your development journey</span>
                </li>
              </ul>
            </div>

            <Button onClick={handleStartTest} className="w-full" size="lg">
              Start Assessment
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (state === "processing") {
    return (
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 space-y-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <h3 className="text-lg font-medium">Processing Your Results</h3>
            <p className="text-muted-foreground text-center">
              Our AI is analyzing your responses and generating personalized recommendations...
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (state === "results" && result) {
    return (
      <div className="max-w-4xl mx-auto">
        <ResultsDisplay result={result} onRetakeTest={handleRetakeTest} />
      </div>
    )
  }

  // Taking test state
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Progress Header */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>
            Question {currentQuestionIndex + 1} of {personalGrowthTest.questions.length}
          </span>
          <span>{Math.round(progress)}% complete</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Question */}
      <QuestionCard
        question={currentQuestion}
        questionNumber={currentQuestionIndex + 1}
        totalQuestions={personalGrowthTest.questions.length}
        value={getCurrentAnswer()}
        onAnswer={handleAnswer}
      />

      {/* Navigation */}
      <div className="flex justify-between">
        <Button variant="outline" onClick={handlePrevious} disabled={currentQuestionIndex === 0}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Previous
        </Button>

        <Button onClick={handleNext} disabled={getCurrentAnswer() === undefined}>
          {isLastQuestion ? "Complete Assessment" : "Next"}
          {!isLastQuestion && <ArrowRight className="ml-2 h-4 w-4" />}
        </Button>
      </div>
    </div>
  )
}
