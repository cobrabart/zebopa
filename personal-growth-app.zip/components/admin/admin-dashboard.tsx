"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AdminStatsOverview } from "./admin-stats"
import { UserManagementTable } from "./user-management"
import { ContentManagementTable } from "./content-management"
import { getAdminStats, getUsers, getContentItems } from "@/lib/admin"
import type { AdminStats, UserManagement, ContentManagement } from "@/lib/admin"

export function AdminDashboard() {
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [users, setUsers] = useState<UserManagement[]>([])
  const [content, setContent] = useState<ContentManagement[]>([])

  useEffect(() => {
    // Load admin data
    setStats(getAdminStats())
    setUsers(getUsers())
    setContent(getContentItems())
  }, [])

  if (!stats) {
    return <div className="flex items-center justify-center py-8">Loading admin dashboard...</div>
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <p className="text-sm text-muted-foreground">Manage users, content, and monitor platform performance</p>
      </div>

      {/* Stats Overview */}
      <AdminStatsOverview stats={stats} />

      {/* Management Tabs */}
      <Tabs defaultValue="users" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4">
          <UserManagementTable users={users} />
        </TabsContent>

        <TabsContent value="content" className="space-y-4">
          <ContentManagementTable content={content} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
