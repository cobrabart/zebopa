"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Activity, Target, BookOpen, TrendingUp, UserCheck } from "lucide-react"
import type { AdminStats } from "@/lib/admin"

interface AdminStatsProps {
  stats: AdminStats
}

export function AdminStatsOverview({ stats }: AdminStatsProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <Card className="p-4">
        <div className="flex items-center justify-between mb-2">
          <Users className="h-5 w-5 text-blue-500" />
          <Badge variant="secondary" className="text-xs">
            Users
          </Badge>
        </div>
        <div className="text-xl font-bold">{stats.totalUsers.toLocaleString()}</div>
        <p className="text-xs text-muted-foreground">total registered</p>
      </Card>

      <Card className="p-4">
        <div className="flex items-center justify-between mb-2">
          <UserCheck className="h-5 w-5 text-green-500" />
          <Badge variant="secondary" className="text-xs">
            Active
          </Badge>
        </div>
        <div className="text-xl font-bold">{stats.activeUsers.toLocaleString()}</div>
        <p className="text-xs text-muted-foreground">active users</p>
      </Card>

      <Card className="p-4">
        <div className="flex items-center justify-between mb-2">
          <Target className="h-5 w-5 text-orange-500" />
          <Badge variant="secondary" className="text-xs">
            Challenges
          </Badge>
        </div>
        <div className="text-xl font-bold">{stats.totalChallenges}</div>
        <p className="text-xs text-muted-foreground">available</p>
      </Card>

      <Card className="p-4">
        <div className="flex items-center justify-between mb-2">
          <BookOpen className="h-5 w-5 text-purple-500" />
          <Badge variant="secondary" className="text-xs">
            Content
          </Badge>
        </div>
        <div className="text-xl font-bold">{stats.totalKnowledgeItems}</div>
        <p className="text-xs text-muted-foreground">knowledge items</p>
      </Card>

      <Card className="p-4 lg:col-span-2">
        <div className="flex items-center justify-between mb-2">
          <Activity className="h-5 w-5 text-cyan-500" />
          <Badge variant="secondary" className="text-xs">
            Completed
          </Badge>
        </div>
        <div className="text-xl font-bold">{stats.completedChallenges.toLocaleString()}</div>
        <p className="text-xs text-muted-foreground">total challenge completions</p>
      </Card>

      <Card className="p-4 lg:col-span-2">
        <div className="flex items-center justify-between mb-2">
          <TrendingUp className="h-5 w-5 text-green-500" />
          <Badge variant="secondary" className="text-xs">
            Engagement
          </Badge>
        </div>
        <div className="text-xl font-bold">{stats.averageEngagement}%</div>
        <p className="text-xs text-muted-foreground">average user engagement</p>
      </Card>
    </div>
  )
}
