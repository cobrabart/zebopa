"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { getUserArticles, deleteArticle, type ArticleSubmission } from "@/lib/articles"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { Search, MoreHorizontal, Edit, Trash2, Eye, Clock, Heart } from "lucide-react"

interface ArticleListProps {
  onEdit?: (article: ArticleSubmission) => void
}

export function ArticleList({ onEdit }: ArticleListProps) {
  const [articles, setArticles] = useState<ArticleSubmission[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredArticles, setFilteredArticles] = useState<ArticleSubmission[]>([])
  const { user } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    if (user) {
      const userArticles = getUserArticles(user.id)
      setArticles(userArticles)
      setFilteredArticles(userArticles)
    }
  }, [user])

  useEffect(() => {
    const filtered = articles.filter(
      (article) =>
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
    )
    setFilteredArticles(filtered)
  }, [searchQuery, articles])

  const handleDelete = async (articleId: string) => {
    try {
      await deleteArticle(articleId)
      setArticles(articles.filter((a) => a.id !== articleId))
      toast({
        title: "Article Deleted",
        description: "Your article has been deleted successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete article",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status: ArticleSubmission["status"]) => {
    switch (status) {
      case "draft":
        return (
          <Badge variant="secondary" className="bg-gray-100 text-gray-800">
            Draft
          </Badge>
        )
      case "submitted":
        return (
          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
            Submitted
          </Badge>
        )
      case "under_review":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
            Under Review
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            Approved
          </Badge>
        )
      case "published":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            Published
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800">
            Rejected
          </Badge>
        )
    }
  }

  const getCategoryIcon = (category: string) => {
    const categoryMap: Record<string, string> = {
      "personal-growth": "🌱",
      mindfulness: "🧘",
      relationships: "💝",
      career: "🎯",
      wellness: "💪",
      creativity: "🎨",
    }
    return categoryMap[category] || "📝"
  }

  if (!user) {
    return (
      <Card className="p-8">
        <div className="text-center space-y-2">
          <p className="text-muted-foreground">Please sign in to view your articles</p>
        </div>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search your articles..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Articles */}
      {filteredArticles.length === 0 ? (
        <Card className="p-8">
          <div className="text-center space-y-2">
            <p className="text-muted-foreground">
              {searchQuery ? "No articles found matching your search" : "You haven't written any articles yet"}
            </p>
            {!searchQuery && (
              <p className="text-sm text-muted-foreground">
                Start sharing your personal growth journey with the community
              </p>
            )}
          </div>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredArticles.map((article) => (
            <Card key={article.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    <span className="text-xl">{getCategoryIcon(article.category)}</span>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg leading-tight text-balance">{article.title}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1 text-pretty">{article.excerpt}</p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onEdit?.(article)}>
                        <Edit className="mr-2 h-4 w-4" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Eye className="mr-2 h-4 w-4" />
                        Preview
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDelete(article.id)} className="text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex flex-wrap items-center gap-2 mb-3">
                  {getStatusBadge(article.status)}
                  {article.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {article.tags.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{article.tags.length - 3} more
                    </Badge>
                  )}
                </div>

                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{article.readingTime} min read</span>
                    </div>
                    {article.status === "published" && (
                      <>
                        <div className="flex items-center space-x-1">
                          <Eye className="h-4 w-4" />
                          <span>{article.views}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Heart className="h-4 w-4" />
                          <span>{article.likes}</span>
                        </div>
                      </>
                    )}
                  </div>
                  <span>
                    {article.publishedAt
                      ? `Published ${article.publishedAt.toLocaleDateString()}`
                      : `Submitted ${article.submittedAt.toLocaleDateString()}`}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
