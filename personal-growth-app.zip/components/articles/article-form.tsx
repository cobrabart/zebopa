"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { articleCategories, calculateReadingTime, generateExcerpt, submitArticle } from "@/lib/articles"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { Save, Send, X, Plus } from "lucide-react"

interface ArticleFormProps {
  onSuccess?: () => void
  onCancel?: () => void
}

export function ArticleForm({ onSuccess, onCancel }: ArticleFormProps) {
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [category, setCategory] = useState("")
  const [tags, setTags] = useState<string[]>([])
  const [newTag, setNewTag] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { user } = useAuth()
  const { toast } = useToast()

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim()) && tags.length < 5) {
      setTags([...tags, newTag.trim().toLowerCase()])
      setNewTag("")
    }
  }

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  const handleSubmit = async (status: "draft" | "submitted") => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to submit articles",
        variant: "destructive",
      })
      return
    }

    if (!title.trim() || !content.trim() || !category) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const article = {
        title: title.trim(),
        content: content.trim(),
        excerpt: generateExcerpt(content),
        author: {
          id: user.id,
          name: user.name,
          email: user.email,
        },
        category,
        tags,
        status,
        readingTime: calculateReadingTime(content),
      }

      await submitArticle(article)

      toast({
        title: status === "draft" ? "Draft Saved" : "Article Submitted",
        description:
          status === "draft" ? "Your article has been saved as a draft" : "Your article has been submitted for review",
      })

      // Reset form
      setTitle("")
      setContent("")
      setCategory("")
      setTags([])
      setNewTag("")

      onSuccess?.()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save article. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const readingTime = content ? calculateReadingTime(content) : 0

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Write Your Article</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Title */}
        <div className="space-y-2">
          <Label htmlFor="title">Title *</Label>
          <Input
            id="title"
            placeholder="Enter your article title..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="text-base"
          />
        </div>

        {/* Category */}
        <div className="space-y-2">
          <Label htmlFor="category">Category *</Label>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger>
              <SelectValue placeholder="Select a category" />
            </SelectTrigger>
            <SelectContent>
              {articleCategories.map((cat) => (
                <SelectItem key={cat.id} value={cat.id}>
                  <div className="flex items-center space-x-2">
                    <span>{cat.icon}</span>
                    <span>{cat.name}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Tags */}
        <div className="space-y-2">
          <Label>Tags (optional)</Label>
          <div className="flex flex-wrap gap-2 mb-2">
            {tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
                <button onClick={() => handleRemoveTag(tag)} className="ml-1 hover:text-destructive">
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
          <div className="flex gap-2">
            <Input
              placeholder="Add a tag..."
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), handleAddTag())}
              className="flex-1"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleAddTag}
              disabled={!newTag.trim() || tags.length >= 5}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">Add up to 5 tags to help readers find your article</p>
        </div>

        {/* Content */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="content">Content *</Label>
            {readingTime > 0 && <span className="text-xs text-muted-foreground">~{readingTime} min read</span>}
          </div>
          <Textarea
            id="content"
            placeholder="Write your article content here... You can use Markdown formatting."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[300px] text-base leading-relaxed"
          />
          <p className="text-xs text-muted-foreground">
            Supports Markdown formatting. Write at least 200 words for a meaningful article.
          </p>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4">
          <Button
            onClick={() => handleSubmit("draft")}
            variant="outline"
            disabled={isSubmitting || !title.trim() || !content.trim()}
            className="flex-1"
          >
            <Save className="mr-2 h-4 w-4" />
            Save as Draft
          </Button>
          <Button
            onClick={() => handleSubmit("submitted")}
            disabled={isSubmitting || !title.trim() || !content.trim() || !category}
            className="flex-1"
          >
            <Send className="mr-2 h-4 w-4" />
            Submit for Review
          </Button>
          {onCancel && (
            <Button onClick={onCancel} variant="ghost" disabled={isSubmitting}>
              Cancel
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
