"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import type { KnowledgeItem, UserProgress } from "@/lib/knowledge"
import { Clock, User, BookOpen, Play, CheckCircle, Bookmark, BookmarkCheck, Star } from "lucide-react"
import Image from "next/image"

interface KnowledgeCardProps {
  item: KnowledgeItem
  progress?: UserProgress | null
  onRead: () => void
  onBookmark: () => void
}

export function KnowledgeCard({ item, progress, onRead, onBookmark }: KnowledgeCardProps) {
  const getTypeIcon = (type: KnowledgeItem["type"]) => {
    switch (type) {
      case "article":
        return "📄"
      case "book":
        return "📚"
      case "video":
        return "🎥"
      case "podcast":
        return "🎧"
      case "exercise":
        return "💪"
      case "guide":
        return "📋"
    }
  }

  const getDifficultyColor = (difficulty: KnowledgeItem["difficulty"]) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "intermediate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "advanced":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
    }
  }

  const getStatusButton = () => {
    if (!progress || progress.status === "not_started") {
      return (
        <Button onClick={onRead} className="w-full">
          <Play className="mr-2 h-4 w-4" />
          Start Reading
        </Button>
      )
    }

    if (progress.status === "in_progress") {
      return (
        <div className="space-y-2">
          <Progress value={progress.progress} className="h-2" />
          <Button onClick={onRead} variant="secondary" className="w-full">
            <BookOpen className="mr-2 h-4 w-4" />
            Continue ({progress.progress}%)
          </Button>
        </div>
      )
    }

    return (
      <div className="space-y-2">
        <div className="flex items-center justify-center space-x-2 text-sm text-green-600 dark:text-green-400">
          <CheckCircle className="h-4 w-4" />
          <span>Completed</span>
          {progress.rating && (
            <div className="flex items-center space-x-1">
              <Star className="h-3 w-3 fill-current" />
              <span>{progress.rating}</span>
            </div>
          )}
        </div>
        <Button onClick={onRead} variant="outline" className="w-full bg-transparent">
          <BookOpen className="mr-2 h-4 w-4" />
          Read Again
        </Button>
      </div>
    )
  }

  return (
    <Card className="h-full flex flex-col group hover:shadow-lg transition-shadow">
      {item.imageUrl && (
        <div className="relative h-48 w-full overflow-hidden rounded-t-lg">
          <Image
            src={item.imageUrl || "/placeholder.svg"}
            alt={item.title}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {item.featured && (
            <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground">Featured</Badge>
          )}
        </div>
      )}

      <CardHeader className="flex-1">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-lg">{getTypeIcon(item.type)}</span>
            <Badge variant="outline" className="text-xs capitalize">
              {item.type}
            </Badge>
            <Badge className={`text-xs ${getDifficultyColor(item.difficulty)}`}>{item.difficulty}</Badge>
          </div>
          <Button variant="ghost" size="sm" onClick={onBookmark} className="p-1 h-auto">
            {progress?.bookmarks ? (
              <BookmarkCheck className="h-4 w-4 text-primary" />
            ) : (
              <Bookmark className="h-4 w-4" />
            )}
          </Button>
        </div>

        <CardTitle className="text-lg leading-tight line-clamp-2">{item.title}</CardTitle>
        <CardDescription className="line-clamp-3">{item.description}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center space-x-1">
            <Clock className="h-4 w-4" />
            <span>{item.readingTime}</span>
          </div>
          <div className="flex items-center space-x-1">
            <User className="h-4 w-4" />
            <span className="truncate max-w-24">{item.author}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-1">
          {item.tags.slice(0, 3).map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
          {item.tags.length > 3 && (
            <Badge variant="secondary" className="text-xs">
              +{item.tags.length - 3}
            </Badge>
          )}
        </div>

        {getStatusButton()}
      </CardContent>
    </Card>
  )
}
