"use client"

import { useState, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { KnowledgeCard } from "./knowledge-card"
import { KnowledgeReader } from "./knowledge-reader"
import {
  knowledgeCategories,
  getKnowledgeItems,
  getUserProgress,
  updateUserProgress,
  searchKnowledgeItems,
  type KnowledgeItem,
  type UserProgress,
} from "@/lib/knowledge"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { Search, BookOpen, TrendingUp, Star, Clock, Sparkles } from "lucide-react"

export function KnowledgeHub() {
  const [selectedItem, setSelectedItem] = useState<KnowledgeItem | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all")
  const [selectedType, setSelectedType] = useState<string>("all")
  const [userProgressMap, setUserProgressMap] = useState<Map<string, UserProgress>>(new Map())
  const { user } = useAuth()
  const { toast } = useToast()

  // Load user progress for displayed items
  const filteredItems = useMemo(() => {
    let items: KnowledgeItem[] = []

    if (searchQuery.trim()) {
      items = searchKnowledgeItems(searchQuery)
    } else {
      items = getKnowledgeItems(
        selectedCategory === "all" ? undefined : selectedCategory,
        selectedDifficulty === "all" ? undefined : selectedDifficulty,
        selectedType === "all" ? undefined : selectedType,
      )
    }

    // Load progress for these items
    if (user) {
      const progressMap = new Map<string, UserProgress>()
      items.forEach((item) => {
        const progress = getUserProgress(user.id, item.id)
        if (progress) {
          progressMap.set(item.id, progress)
        }
      })
      setUserProgressMap(progressMap)
    }

    return items
  }, [searchQuery, selectedCategory, selectedDifficulty, selectedType, user])

  const featuredItems = useMemo(() => {
    return getKnowledgeItems(undefined, undefined, undefined, true).slice(0, 3)
  }, [])

  const handleReadItem = (item: KnowledgeItem) => {
    setSelectedItem(item)

    // Mark as started if not already
    if (user) {
      const progress = userProgressMap.get(item.id)
      if (!progress || progress.status === "not_started") {
        updateUserProgress(user.id, item.id, {
          status: "in_progress",
          progress: 0,
          startedAt: new Date(),
        }).then((newProgress) => {
          setUserProgressMap((prev) => new Map(prev.set(item.id, newProgress)))
        })
      }
    }
  }

  const handleBookmarkItem = async (item: KnowledgeItem) => {
    if (!user) {
      toast({
        title: "Sign In Required",
        description: "Please sign in to bookmark items",
        variant: "destructive",
      })
      return
    }

    const currentProgress = userProgressMap.get(item.id)
    const newBookmarkState = !currentProgress?.bookmarks

    try {
      const updatedProgress = await updateUserProgress(user.id, item.id, {
        bookmarks: newBookmarkState,
        status: currentProgress?.status || "not_started",
      })

      setUserProgressMap((prev) => new Map(prev.set(item.id, updatedProgress)))

      toast({
        title: newBookmarkState ? "Bookmarked" : "Bookmark Removed",
        description: newBookmarkState ? "Added to your bookmarks" : "Removed from bookmarks",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update bookmark",
        variant: "destructive",
      })
    }
  }

  const handleProgressUpdate = (progress: UserProgress) => {
    setUserProgressMap((prev) => new Map(prev.set(progress.itemId, progress)))
  }

  const handleBackToHub = () => {
    setSelectedItem(null)
  }

  if (selectedItem) {
    return (
      <KnowledgeReader
        item={selectedItem}
        progress={userProgressMap.get(selectedItem.id)}
        onBack={handleBackToHub}
        onProgressUpdate={handleProgressUpdate}
      />
    )
  }

  return (
    <div className="space-y-6">
      {/* Header - Mobile Optimized */}
      <div className="text-center space-y-3">
        <div className="flex items-center justify-center space-x-2">
          <div className="p-2 bg-primary/10 rounded-full">
            <BookOpen className="h-6 w-6 text-primary" />
          </div>
          <h1 className="text-2xl font-bold">Knowledge Hub</h1>
        </div>
        <p className="text-sm text-muted-foreground text-pretty px-4 leading-relaxed">
          Discover curated content to accelerate your personal growth journey.
        </p>
      </div>

      {/* Stats - Mobile Grid */}
      {user && (
        <div className="grid grid-cols-2 gap-3">
          <Card className="p-4">
            <div className="flex items-center justify-between mb-2">
              <BookOpen className="h-5 w-5 text-primary" />
              <Badge variant="secondary" className="text-xs">
                Read
              </Badge>
            </div>
            <div className="text-xl font-bold">
              {Array.from(userProgressMap.values()).filter((p) => p.status === "completed").length}
            </div>
            <p className="text-xs text-muted-foreground">completed</p>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="h-5 w-5 text-yellow-500" />
              <Badge variant="secondary" className="text-xs">
                Active
              </Badge>
            </div>
            <div className="text-xl font-bold">
              {Array.from(userProgressMap.values()).filter((p) => p.status === "in_progress").length}
            </div>
            <p className="text-xs text-muted-foreground">in progress</p>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between mb-2">
              <Star className="h-5 w-5 text-orange-500" />
              <Badge variant="secondary" className="text-xs">
                Saved
              </Badge>
            </div>
            <div className="text-xl font-bold">
              {Array.from(userProgressMap.values()).filter((p) => p.bookmarks).length}
            </div>
            <p className="text-xs text-muted-foreground">bookmarked</p>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between mb-2">
              <Clock className="h-5 w-5 text-green-500" />
              <Badge variant="secondary" className="text-xs">
                Time
              </Badge>
            </div>
            <div className="text-xl font-bold">2.5h</div>
            <p className="text-xs text-muted-foreground">reading time</p>
          </Card>
        </div>
      )}

      {/* Featured Content - Mobile Optimized */}
      {featuredItems.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-yellow-500" />
            <h2 className="text-lg font-semibold">Featured Content</h2>
          </div>
          <div className="space-y-4">
            {featuredItems.map((item) => (
              <KnowledgeCard
                key={item.id}
                item={item}
                progress={userProgressMap.get(item.id)}
                onRead={() => handleReadItem(item)}
                onBookmark={() => handleBookmarkItem(item)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Search - Mobile Optimized */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search articles, guides, exercises..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-12"
          />
        </div>

        {/* Quick Filter Buttons */}
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedCategory === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory("all")}
            className="text-xs"
          >
            All
          </Button>
          {knowledgeCategories.slice(0, 3).map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className="text-xs"
            >
              {category.name.split(" ")[0]}
            </Button>
          ))}
        </div>
      </div>

      {/* Content Grid - Mobile Optimized */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">{searchQuery ? `Results` : "All Content"}</h2>
          <Badge variant="secondary" className="text-xs">
            {filteredItems.length}
          </Badge>
        </div>

        {filteredItems.length === 0 ? (
          <Card className="p-8">
            <div className="text-center space-y-2">
              <p className="text-muted-foreground">No content found</p>
              <p className="text-sm text-muted-foreground">Try adjusting your search</p>
            </div>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredItems.map((item) => (
              <KnowledgeCard
                key={item.id}
                item={item}
                progress={userProgressMap.get(item.id)}
                onRead={() => handleReadItem(item)}
                onBookmark={() => handleBookmarkItem(item)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
