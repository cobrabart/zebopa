"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import type { KnowledgeItem, UserProgress } from "@/lib/knowledge"
import { updateUserProgress } from "@/lib/knowledge"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import {
  ArrowLeft,
  Clock,
  User,
  Bookmark,
  BookmarkCheck,
  Star,
  CheckCircle,
  Download,
  ExternalLink,
} from "lucide-react"
import ReactMarkdown from "react-markdown"

interface KnowledgeReaderProps {
  item: KnowledgeItem
  progress?: UserProgress | null
  onBack: () => void
  onProgressUpdate: (progress: UserProgress) => void
}

export function KnowledgeReader({ item, progress, onBack, onProgressUpdate }: KnowledgeReaderProps) {
  const [readingProgress, setReadingProgress] = useState(progress?.progress || 0)
  const [notes, setNotes] = useState(progress?.notes || "")
  const [rating, setRating] = useState(progress?.rating || 0)
  const [isBookmarked, setIsBookmarked] = useState(progress?.bookmarks || false)
  const { user } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    // Simulate reading progress
    const interval = setInterval(() => {
      if (readingProgress < 100) {
        setReadingProgress((prev) => Math.min(prev + 2, 100))
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [readingProgress])

  useEffect(() => {
    // Auto-save progress
    if (user && readingProgress > (progress?.progress || 0)) {
      handleProgressUpdate({
        status: readingProgress >= 100 ? "completed" : "in_progress",
        progress: readingProgress,
        ...(readingProgress >= 100 && { completedAt: new Date() }),
      })
    }
  }, [readingProgress, user, progress?.progress])

  const handleProgressUpdate = async (updates: Partial<UserProgress>) => {
    if (!user) return

    try {
      const updatedProgress = await updateUserProgress(user.id, item.id, updates)
      onProgressUpdate(updatedProgress)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update progress",
        variant: "destructive",
      })
    }
  }

  const handleBookmark = async () => {
    const newBookmarkState = !isBookmarked
    setIsBookmarked(newBookmarkState)

    await handleProgressUpdate({
      bookmarks: newBookmarkState,
      status: progress?.status || "in_progress",
    })

    toast({
      title: newBookmarkState ? "Bookmarked" : "Bookmark Removed",
      description: newBookmarkState ? "Added to your bookmarks" : "Removed from bookmarks",
    })
  }

  const handleRating = async (newRating: number) => {
    setRating(newRating)
    await handleProgressUpdate({
      rating: newRating,
      status: "completed",
      progress: 100,
    })

    toast({
      title: "Rating Saved",
      description: `You rated this ${newRating} star${newRating !== 1 ? "s" : ""}`,
    })
  }

  const handleSaveNotes = async () => {
    await handleProgressUpdate({
      notes,
      status: progress?.status || "in_progress",
    })

    toast({
      title: "Notes Saved",
      description: "Your notes have been saved",
    })
  }

  const getDifficultyColor = (difficulty: KnowledgeItem["difficulty"]) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "intermediate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "advanced":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
    }
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Knowledge Hub
        </Button>

        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" onClick={handleBookmark}>
            {isBookmarked ? <BookmarkCheck className="h-4 w-4 text-primary" /> : <Bookmark className="h-4 w-4" />}
          </Button>

          {item.downloadUrl && (
            <Button variant="ghost" size="sm" asChild>
              <a href={item.downloadUrl} download>
                <Download className="h-4 w-4" />
              </a>
            </Button>
          )}

          {item.externalUrl && (
            <Button variant="ghost" size="sm" asChild>
              <a href={item.externalUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          )}
        </div>
      </div>

      {/* Progress Bar */}
      {readingProgress > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Reading Progress</span>
              <span className="text-sm text-muted-foreground">{readingProgress}%</span>
            </div>
            <Progress value={readingProgress} className="h-2" />
            {readingProgress >= 100 && (
              <div className="flex items-center justify-center mt-2 text-green-600 dark:text-green-400">
                <CheckCircle className="h-4 w-4 mr-2" />
                <span className="text-sm">Completed!</span>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Article Content */}
      <Card>
        <CardHeader>
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className="capitalize">
                {item.type}
              </Badge>
              <Badge className={getDifficultyColor(item.difficulty)}>{item.difficulty}</Badge>
              <Badge variant="secondary" className="capitalize">
                {item.category.replace("-", " ")}
              </Badge>
            </div>

            <CardTitle className="text-3xl leading-tight">{item.title}</CardTitle>

            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <User className="h-4 w-4" />
                  <span>{item.author}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>{item.readingTime}</span>
                </div>
              </div>
              <span>{item.publishedAt.toLocaleDateString()}</span>
            </div>

            <div className="flex flex-wrap gap-1">
              {item.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        </CardHeader>

        <CardContent className="prose prose-gray dark:prose-invert max-w-none">
          <ReactMarkdown>{item.content}</ReactMarkdown>
        </CardContent>
      </Card>

      {/* Rating Section */}
      {readingProgress >= 100 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Rate This Content</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Button key={star} variant="ghost" size="sm" onClick={() => handleRating(star)} className="p-1">
                  <Star className={`h-6 w-6 ${star <= rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
                </Button>
              ))}
              {rating > 0 && <span className="text-sm text-muted-foreground ml-2">{rating}/5 stars</span>}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Notes Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Personal Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="notes">Your thoughts and key takeaways</Label>
            <Textarea
              id="notes"
              placeholder="What did you learn? How will you apply this knowledge?"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="mt-2 min-h-[100px]"
            />
          </div>
          <Button onClick={handleSaveNotes} disabled={!notes.trim()}>
            Save Notes
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
