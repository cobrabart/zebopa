"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { BadgeCard } from "./badge-card"
import { Leaderboard } from "./leaderboard"
import { getUserStats, getUserAchievements, availableBadges } from "@/lib/gamification"
import { useAuth } from "@/hooks/use-auth"
import { Trophy, Target, BookOpen, Calendar, TrendingUp, Star, Flame, Award } from "lucide-react"

export function ProgressOverview() {
  const { user } = useAuth()

  if (!user) return null

  const userStats = getUserStats(user.id)
  const userAchievements = getUserAchievements(user.id)

  if (!userStats) return null

  const earnedBadges = userAchievements.filter((a) => a.isCompleted)
  const inProgressBadges = userAchievements.filter((a) => !a.isCompleted)
  const availableForEarning = availableBadges.filter((badge) => !userAchievements.some((a) => a.badgeId === badge.id))

  const levelProgress = ((userStats.totalPoints % 500) / 500) * 100
  const nextLevelPoints = userStats.level * 500 - userStats.totalPoints

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold">Your Progress</h1>
        <p className="text-muted-foreground text-pretty">
          Track your growth journey, earn badges, and see how you compare with others
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Level</CardTitle>
            <Star className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Level {userStats.level}</div>
            <Progress value={levelProgress} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-1">
              {nextLevelPoints} points to Level {userStats.level + 1}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Streak</CardTitle>
            <Flame className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userStats.currentStreak} days</div>
            <p className="text-xs text-muted-foreground">Best: {userStats.longestStreak} days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Points</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userStats.totalPoints.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">From {userStats.challengesCompleted} challenges</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Badges Earned</CardTitle>
            <Award className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{earnedBadges.length}</div>
            <p className="text-xs text-muted-foreground">of {availableBadges.length} available</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Activity Summary</CardTitle>
            <CardDescription>Your engagement across different areas</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Target className="h-4 w-4 text-primary" />
                <span className="text-sm">Challenges Completed</span>
              </div>
              <Badge variant="secondary">{userStats.challengesCompleted}</Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <BookOpen className="h-4 w-4 text-primary" />
                <span className="text-sm">Articles Read</span>
              </div>
              <Badge variant="secondary">{userStats.articlesRead}</Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Trophy className="h-4 w-4 text-primary" />
                <span className="text-sm">Assessments Taken</span>
              </div>
              <Badge variant="secondary">{userStats.assessmentsTaken}</Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4 text-primary" />
                <span className="text-sm">Days Active</span>
              </div>
              <Badge variant="secondary">{userStats.daysActive}</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Achievements</CardTitle>
            <CardDescription>Your latest badge unlocks</CardDescription>
          </CardHeader>
          <CardContent>
            {earnedBadges.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                Complete your first challenge to earn your first badge!
              </p>
            ) : (
              <div className="space-y-3">
                {earnedBadges
                  .sort((a, b) => b.unlockedAt.getTime() - a.unlockedAt.getTime())
                  .slice(0, 3)
                  .map((achievement) => {
                    const badge = availableBadges.find((b) => b.id === achievement.badgeId)
                    if (!badge) return null

                    return (
                      <div key={achievement.id} className="flex items-center space-x-3 p-2 rounded-lg bg-muted/50">
                        <div className="text-2xl">{badge.icon}</div>
                        <div className="flex-1">
                          <div className="font-medium text-sm">{badge.name}</div>
                          <div className="text-xs text-muted-foreground">
                            Unlocked {achievement.unlockedAt.toLocaleDateString()}
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          +{badge.points}
                        </Badge>
                      </div>
                    )
                  })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Badges Section */}
      <div className="space-y-6">
        {/* Earned Badges */}
        {earnedBadges.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Earned Badges ({earnedBadges.length})</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {earnedBadges.map((achievement) => {
                const badge = availableBadges.find((b) => b.id === achievement.badgeId)
                if (!badge) return null

                return <BadgeCard key={achievement.id} badge={badge} achievement={achievement} showProgress={false} />
              })}
            </div>
          </div>
        )}

        {/* In Progress Badges */}
        {inProgressBadges.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">In Progress ({inProgressBadges.length})</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {inProgressBadges.map((achievement) => {
                const badge = availableBadges.find((b) => b.id === achievement.badgeId)
                if (!badge) return null

                return <BadgeCard key={achievement.id} badge={badge} achievement={achievement} />
              })}
            </div>
          </div>
        )}

        {/* Available Badges */}
        {availableForEarning.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Available to Earn ({availableForEarning.length})</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {availableForEarning.slice(0, 8).map((badge) => (
                <BadgeCard key={badge.id} badge={badge} showProgress={false} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Leaderboard */}
      <Leaderboard />
    </div>
  )
}
