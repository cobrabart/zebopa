"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { ChallengeCard } from "./challenge-card"
import { ChallengeDetail } from "./challenge-detail"
import {
  type Challenge,
  type UserProgress,
  getTodaysChallenge,
  getUserProgress,
  startChallenge,
} from "@/lib/challenges"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { Calendar, Target, TrendingUp, Flame } from "lucide-react"

export function DailyChallenge() {
  const [todaysChallenge, setTodaysChallenge] = useState<Challenge | null>(null)
  const [progress, setProgress] = useState<UserProgress | null>(null)
  const [showDetail, setShowDetail] = useState(false)
  const { user, updateUser } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    if (user) {
      const challenge = getTodaysChallenge()
      const userProgress = getUserProgress(user.id, challenge.id)
      setTodaysChallenge(challenge)
      setProgress(userProgress)
    }
  }, [user])

  const handleStartChallenge = async () => {
    if (!user || !todaysChallenge) return

    try {
      const newProgress = await startChallenge(user.id, todaysChallenge.id)
      setProgress(newProgress)
      setShowDetail(true)

      toast({
        title: "Challenge Started!",
        description: "Good luck with today's challenge. You've got this!",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start challenge. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleContinueChallenge = () => {
    setShowDetail(true)
  }

  const handleViewSubmission = () => {
    setShowDetail(true)
  }

  const handleChallengeComplete = () => {
    if (!user || !todaysChallenge) return

    // Update user stats
    const newStreak = progress?.status === "completed" ? user.streak : user.streak + 1
    const newPoints = user.totalPoints + todaysChallenge.points
    const newLevel = Math.floor(newPoints / 500) + 1

    updateUser({
      streak: newStreak,
      totalPoints: newPoints,
      level: newLevel,
    })

    // Refresh progress
    const updatedProgress = getUserProgress(user.id, todaysChallenge.id)
    setProgress(updatedProgress)
    setShowDetail(false)
  }

  const handleBack = () => {
    setShowDetail(false)
  }

  if (!todaysChallenge) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <p className="text-muted-foreground">Loading today's challenge...</p>
        </CardContent>
      </Card>
    )
  }

  if (showDetail) {
    return (
      <ChallengeDetail
        challenge={todaysChallenge}
        progress={progress}
        onBack={handleBack}
        onComplete={handleChallengeComplete}
      />
    )
  }

  return (
    <div className="space-y-6">
      {/* Header - Mobile Optimized */}
      <div className="text-center space-y-3">
        <div className="flex items-center justify-center space-x-2">
          <div className="p-2 bg-primary/10 rounded-full">
            <Calendar className="h-5 w-5 text-primary" />
          </div>
          <h1 className="text-xl font-bold">Today's Challenge</h1>
        </div>
        <p className="text-sm text-muted-foreground px-4">
          {new Date().toLocaleDateString("en-US", {
            weekday: "long",
            month: "short",
            day: "numeric",
          })}
        </p>
      </div>

      {/* Challenge Card - Mobile Optimized */}
      <div className="w-full">
        <ChallengeCard
          challenge={todaysChallenge}
          progress={progress}
          onStart={handleStartChallenge}
          onContinue={handleContinueChallenge}
          onView={handleViewSubmission}
        />
      </div>

      {/* Quick Stats - Mobile Grid */}
      {user && (
        <div className="space-y-3">
          <h2 className="text-lg font-semibold">Your Progress</h2>
          <div className="grid grid-cols-2 gap-3">
            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Flame className="h-5 w-5 text-orange-500" />
                <span className="text-xs text-muted-foreground">Streak</span>
              </div>
              <div className="text-xl font-bold">{user.streak}</div>
              <p className="text-xs text-muted-foreground">days strong</p>
            </Card>

            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="h-5 w-5 text-green-500" />
                <span className="text-xs text-muted-foreground">This Month</span>
              </div>
              <div className="text-xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">challenges</p>
            </Card>
          </div>

          <Card className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Target className="h-5 w-5 text-blue-500" />
                <span className="font-medium">Completion Rate</span>
              </div>
              <span className="text-2xl font-bold text-blue-500">85%</span>
            </div>
            <p className="text-xs text-muted-foreground">Keep up the great work!</p>
          </Card>
        </div>
      )}
    </div>
  )
}
