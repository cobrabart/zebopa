"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { type Challenge, type UserProgress, submitChallenge } from "@/lib/challenges"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { Clock, Star, CheckCircle, ArrowLeft, Send } from "lucide-react"

interface ChallengeDetailProps {
  challenge: Challenge
  progress?: UserProgress | null
  onBack: () => void
  onComplete: () => void
}

export function ChallengeDetail({ challenge, progress, onBack, onComplete }: ChallengeDetailProps) {
  const [content, setContent] = useState("")
  const [reflection, setReflection] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { user } = useAuth()
  const { toast } = useToast()

  const handleSubmit = async () => {
    if (!user || !content.trim()) {
      toast({
        title: "Missing Content",
        description: "Please provide your response before submitting",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    try {
      await submitChallenge(user.id, challenge.id, content, undefined, undefined, reflection)

      // Update user points
      user.totalPoints += challenge.points

      toast({
        title: "Challenge Completed!",
        description: `You earned ${challenge.points} points. Great work!`,
      })

      onComplete()
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const getDifficultyColor = (difficulty: Challenge["difficulty"]) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "hard":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
    }
  }

  const isCompleted = progress?.status === "completed"

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        {isCompleted && <CheckCircle className="h-5 w-5 text-green-500" />}
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-2xl">{challenge.title}</CardTitle>
              <CardDescription className="text-base mt-2">{challenge.description}</CardDescription>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mt-4">
            <Badge variant="secondary" className={getDifficultyColor(challenge.difficulty)}>
              {challenge.difficulty}
            </Badge>
            <Badge variant="outline">{challenge.category}</Badge>
            {challenge.tags.map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>

          <div className="flex items-center justify-between text-sm text-muted-foreground mt-4">
            <div className="flex items-center space-x-1">
              <Clock className="h-4 w-4" />
              <span>{challenge.estimatedTime}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4" />
              <span>{challenge.points} points</span>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-3">Instructions</h3>
            <ol className="space-y-2">
              {challenge.instructions.map((instruction, index) => (
                <li key={index} className="flex items-start space-x-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                    {index + 1}
                  </span>
                  <span className="text-sm">{instruction}</span>
                </li>
              ))}
            </ol>
          </div>

          <Separator />

          {isCompleted && progress?.submission ? (
            <div className="space-y-4">
              <h3 className="font-semibold">Your Submission</h3>
              <div className="bg-muted p-4 rounded-lg">
                <p className="whitespace-pre-wrap">{progress.submission.content}</p>
              </div>
              {progress.submission.reflection && (
                <div>
                  <h4 className="font-medium mb-2">Reflection</h4>
                  <div className="bg-muted p-4 rounded-lg">
                    <p className="whitespace-pre-wrap">{progress.submission.reflection}</p>
                  </div>
                </div>
              )}
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Completed on {progress.submission.completedAt.toLocaleDateString()}</span>
                <span>•</span>
                <span>{progress.submission.points} points earned</span>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <Label htmlFor="content">Your Response *</Label>
                <Textarea
                  id="content"
                  placeholder="Share your experience, thoughts, or what you accomplished..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="mt-2 min-h-[120px]"
                />
              </div>

              <div>
                <Label htmlFor="reflection">Personal Reflection (Optional)</Label>
                <Textarea
                  id="reflection"
                  placeholder="How did this challenge make you feel? What did you learn?"
                  value={reflection}
                  onChange={(e) => setReflection(e.target.value)}
                  className="mt-2"
                />
              </div>

              <Button onClick={handleSubmit} disabled={isSubmitting || !content.trim()} className="w-full">
                {isSubmitting ? (
                  "Submitting..."
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Submit Challenge
                  </>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
