"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Mail, Lock } from "lucide-react"
import { useTranslation } from "@/lib/translations"

interface LoginFormProps {
  onToggleMode: () => void
}

export function LoginForm({ onToggleMode }: LoginFormProps) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const { signIn, isLoading } = useAuth()
  const { toast } = useToast()
  const { t } = useTranslation("uz")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !password) {
      toast({
        title: "Ma'lumot yetishmayapti",
        description: "Iltimos, barcha maydonlarni to'ldiring",
        variant: "destructive",
      })
      return
    }

    const success = await signIn(email, password)

    if (success) {
      toast({
        title: "Xush kelibsiz!",
        description: "Hisobingizga muvaffaqiyatli kirdingiz",
      })
    } else {
      toast({
        title: "Kirish amalga oshmadi",
        description: "Noto'g'ri email yoki parol. demo@example.com / demo123 ni sinab ko'ring",
        variant: "destructive",
      })
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold text-primary">{t("auth.welcome")}</CardTitle>
        <CardDescription>O'sish yo'lingizni davom ettirish uchun kiring</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">{t("auth.email")}</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                placeholder="Elektron pochtangizni kiriting"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10"
                disabled={isLoading}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">{t("auth.password")}</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="password"
                type="password"
                placeholder="Parolingizni kiriting"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10"
                disabled={isLoading}
              />
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Kirilmoqda...
              </>
            ) : (
              t("auth.loginButton")
            )}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            {t("auth.dontHaveAccount")}{" "}
            <button type="button" onClick={onToggleMode} className="text-primary hover:underline font-medium">
              {t("auth.createAccount")}
            </button>
          </p>
          <div className="mt-4 p-3 bg-muted rounded-lg">
            <p className="text-xs text-muted-foreground">Demo: demo@example.com / demo123</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
