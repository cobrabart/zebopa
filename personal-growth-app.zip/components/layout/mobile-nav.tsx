"use client"

import { HomeIcon, TargetIcon, BookIcon, TrophyIcon, ShieldIcon, PenIcon } from "@/components/icons/modern-icons"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { useAuth } from "@/hooks/use-auth"
import { useTranslation } from "@/lib/translations"

export function MobileNav() {
  const pathname = usePathname()
  const { user } = useAuth()
  const { t } = useTranslation("uz")

  const navItems = [
    {
      href: "/",
      icon: HomeIcon,
      label: t("nav.home"),
    },
    {
      href: "/challenges",
      icon: TargetIcon,
      label: t("nav.challenges"),
    },
    {
      href: "/knowledge",
      icon: BookIcon,
      label: t("nav.knowledge"),
    },
    {
      href: "/articles",
      icon: PenIcon,
      label: "Yozish",
    },
    {
      href: "/progress",
      icon: TrophyIcon,
      label: t("nav.progress"),
    },
  ]

  // Add admin nav item for admin users, but keep main nav compact
  const isAdmin = user?.email === "demo@example.com"
  const showAdminInMain = false // Keep admin separate for cleaner UX

  const allNavItems =
    showAdminInMain && isAdmin
      ? [...navItems.slice(0, 4), { href: "/admin", icon: ShieldIcon, label: "Admin" }]
      : navItems

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background border-t shadow-lg">
      <div className="flex items-center justify-around px-2 py-2">
        {allNavItems.map((item) => {
          const isActive = pathname === item.href
          const Icon = item.icon

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center min-w-0 flex-1 px-2 py-2 rounded-lg transition-colors",
                isActive
                  ? "text-primary-foreground bg-primary font-medium"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/80",
              )}
            >
              <Icon className="h-5 w-5 mb-1" />
              <span
                className={cn(
                  "text-xs font-medium truncate",
                  isActive ? "text-primary-foreground" : "text-muted-foreground",
                )}
              >
                {item.label}
              </span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
