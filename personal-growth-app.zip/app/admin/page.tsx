"use client"

import { useAuth } from "@/hooks/use-auth"
import { MobileHeader } from "@/components/layout/mobile-header"
import { MobileNav } from "@/components/layout/mobile-nav"
import { AdminDashboard } from "@/components/admin/admin-dashboard"
import { Card } from "@/components/ui/card"
import { Shield } from "lucide-react"

export default function AdminPage() {
  const { user } = useAuth()

  // Simple admin check - in real app, this would be more sophisticated
  const isAdmin = user?.email === "demo@example.com"

  if (!user) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <MobileHeader />
        <main className="px-4 py-6">
          <Card className="p-8">
            <div className="text-center space-y-2">
              <p className="text-muted-foreground">Please sign in to access admin panel</p>
            </div>
          </Card>
        </main>
        <MobileNav />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <MobileHeader />
        <main className="px-4 py-6">
          <Card className="p-8">
            <div className="text-center space-y-3">
              <Shield className="h-12 w-12 text-muted-foreground mx-auto" />
              <h2 className="text-lg font-semibold">Access Denied</h2>
              <p className="text-muted-foreground">You don't have permission to access the admin panel</p>
            </div>
          </Card>
        </main>
        <MobileNav />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <MobileHeader />
      <main className="px-4 py-6">
        <AdminDashboard />
      </main>
      <MobileNav />
    </div>
  )
}
