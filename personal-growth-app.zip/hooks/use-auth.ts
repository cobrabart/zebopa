"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import { type User, type AuthState, signIn, signUp, signOut } from "@/lib/auth"

interface AuthStore extends AuthState {
  signIn: (email: string, password: string) => Promise<boolean>
  signUp: (email: string, password: string, name: string) => Promise<boolean>
  signOut: () => Promise<void>
  updateUser: (updates: Partial<User>) => void
}

export const useAuth = create<AuthStore>()(
  persist(
    (set, get) => ({
      user: null,
      isLoading: false,
      isAuthenticated: false,

      signIn: async (email: string, password: string) => {
        set({ isLoading: true })
        try {
          const user = await signIn(email, password)
          if (user) {
            set({ user, isAuthenticated: true, isLoading: false })
            return true
          }
          set({ isLoading: false })
          return false
        } catch (error) {
          set({ isLoading: false })
          return false
        }
      },

      signUp: async (email: string, password: string, name: string) => {
        set({ isLoading: true })
        try {
          const user = await signUp(email, password, name)
          if (user) {
            set({ user, isAuthenticated: true, isLoading: false })
            return true
          }
          set({ isLoading: false })
          return false
        } catch (error) {
          set({ isLoading: false })
          return false
        }
      },

      signOut: async () => {
        set({ isLoading: true })
        try {
          await signOut()
          set({ user: null, isAuthenticated: false, isLoading: false })
        } catch (error) {
          set({ isLoading: false })
        }
      },

      updateUser: (updates: Partial<User>) => {
        const { user } = get()
        if (user) {
          set({ user: { ...user, ...updates } })
        }
      },
    }),
    {
      name: "auth-storage",
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
    },
  ),
)
